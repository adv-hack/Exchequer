RichView 13.0.5
Full source code (without help and demo projects)

See "New in version 13" in the help file.
------------------------------

Additional files:

Help, demos:
http://www.trichview.com/rvfiles/rvhelp.zip
RichViewActions:
http://www.trichview.com/resources/actions/richviewactions.zip

FAQ about installing:
http://www.trichview.com/install-faq.html

------------------------------
History

v13.0.5 (2011-May-4)
v13.0.4 (2011-May-2)
v13.0.3 (2011-Apr-20)
v13.0.2 (2011-Apr-5)
v13.0.1 (2011-Mar-18)
v13.0 (2011-Mar-17)