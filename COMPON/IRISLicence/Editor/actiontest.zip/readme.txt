RichViewActions Demo

(c) http://www.trichview.com
Sergey Tkachenko <svt@trichview.com>
More information:
http://www.trichview.com/resources/actions/

This demo uses several freeware third-party components:

* RvHtmlImporter
Used for inserting HTML files and pasting them from the Clipboard ("Paste Special" command)
http://www.trichview.com/resources/

* RichViewXML
Used for saving, loading and inserting RichView Documents in XML format.
http://www.trichview.com/resources/xml/

* Indy
TIdHTTP is used for downloading images when inserting HTML or RTF files.


October 2, 2010