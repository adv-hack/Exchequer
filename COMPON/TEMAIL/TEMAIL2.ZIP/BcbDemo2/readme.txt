
This is a slightly more VCL-style
Borland C++ Builder demonstration
project than the one found in the
BcbDemo1 folder.

The original files have been
created by 

  Gerald Patel (G.Patel@Wanadoo.fr)


All errors in this demo should be
attributed to

  Stefan Hoffmeister

    Stefan.Hoffmeister@PoBoxes.com
