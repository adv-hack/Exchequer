using System;
using System.Collections.Generic;
using System.Text;

namespace IRIS.ICE.Common
{
    public class Class1
    {
    }
}
